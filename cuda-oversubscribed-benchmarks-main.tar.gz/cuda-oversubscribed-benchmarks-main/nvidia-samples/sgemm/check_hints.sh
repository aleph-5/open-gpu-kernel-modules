#!/bin/bash

data_sizes="5500 10000 15000 17000 17500"
data_sizes="15000 17500"

for d in $data_sizes; do
    for hints in    \
            "-accby-gpu 2"  \
            "-accby-gpu 2 -readmostly 1"    \
            "-accby-gpu 1 -accby-gpu 3"     \
            "-accby-gpu all"
    do
        cmd="./sgemm.out -mb $d $hints"
        echo Running $cmd
        time $cmd

    done
done

