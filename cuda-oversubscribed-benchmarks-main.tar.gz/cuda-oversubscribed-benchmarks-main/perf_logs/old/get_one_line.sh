#!/bin/bash
# get one line from atax/2DCONV logs, do this for each data size and kernel type.

echo "# Assuming data sizes 8G 9G 10G 11G 12G"
driver_types="vanilla rd_dup"
echo "# Driver types" $driver_types

# sometimes we want to print to console, at other times we want to feed to python
pipe_to_cmd="cat"

usage () {
    echo "./$0 -b <benchmarks> [-p] [-f]"
    echo "-p to pipe to python3 make_plot.py"
    echo "-f to make it fast"
    echo 'For multiple benchmarks, use quotes: -b "atax bfs pagerank X Y"'
    exit 3
}

while getopts "fphb:" o
do
    echo "${o}"
    case "${o}" in
        p)
            echo "will pipe output to python"
            pipe_to_cmd="python3 make_plot.py"
            ;;
        h)
            echo "nice to ask for help"
            usage
            ;;
        b)
            benchmark=${OPTARG}
            echo Going with benchmark ${OPTARG}
            ;;
        f)
            echo  "one graph only"
            exit_after_first_statistic=1
            ;;
        *)
            echo stray flag!
            usage
            ;;
    esac
done

if [ -z "$benchmark" ]
then
    usage
    exit 2
fi



search_for_timeout () {
    if [ $(grep -c "Timed out or killed" $1) -ne 0 ]
    then
        echo -n " TIMED_OUT"
    fi
}

search_mmap_size () {
    if [ $(grep -c "uvm_mmap_data_size" $1) -ne 1 ]
    then
        echo SOMETHING wrong $1 mmap data size
        exit 23
    fi

    echo -n " mmap_"
    grep uvm_mmap_data_size $1 | cut -f 4
}

# $1 benchmark name
# $2 search key
# $3 saral shabdo me for the plot title
get_one_suneo_line () {
    for driver_type in $driver_types
    do
        for data_size in 8000000000 9000000000 10000000000 11000000000 12000000000
        do
            log_file=suneo_$driver_type*$1*$data_size*
            echo -n $1 $2 $data_size $driver_type " "
            grep $2 $log_file | tr -d '\n'
            search_mmap_size $log_file | tr -d '\n'
            echo -n " " $3
            search_for_timeout $log_file
            echo ""
        done

    done
    echo
    echo
}

# similar to above, just doesn't assume data sizes
get_one_statistic () {
    for driver_type in $driver_types
    do
        all_data_sizes=`echo suneo_$driver_type*$1*`
        echo found log files $all_data_sizes > /dev/stderr
        for log_file in $all_data_sizes
        do
            echo -n $1 $2 $driver_type " "
            grep $2 $log_file | tr -d '\n'
            search_mmap_size $log_file | tr -d '\n'
            echo -n " " $3
            search_for_timeout $log_file
            echo ""
        done

    done | $pipe_to_cmd
    echo
    echo
}

for b in $benchmark
do
    get_one_statistic $b gpu_dedup_read_faults "GPU read faults"
    if [ -n "$exit_after_first_statistic" ]
    then
        exit 1
    fi
    get_one_statistic $b gpu_dedup_write_faults "GPU write faults"
    get_one_statistic $b H2D_num_prefetch_pages "H2D prefetch count with false prefetches"
    get_one_statistic $b gpu_readonly_page_count  "Pages mapped RO to GPU"
    get_one_statistic $b gpu_readwrite_page_count "Pages mapped RW to GPU"
    get_one_statistic $b gpu_write_to_rdup_page_count "GPU protection (minor) faults"
    get_one_statistic $b evict_chunk "VA blocks evicted"
done


